img=imread('maple.jpg');


%SCHEME1 PURE IMAGE PROCESSING
% img=rgb2gray(img);
% img=im2bw(img,0.61);
% img=imfill(~img,'hole');
% str=strel('disk',3);
% img=imerode(~img,str);
% img=bwareaopen(~img,100);
% img=imdilate(~img,str);
% img=imdilate(img,str);
% img=imerode(img,str);
% figure
% imshow(img)
% str=strel('disk',2);
% img1=imerode(img,str);
% img2=img-img1;
% figure
% imshow(img2)


%  SCHEME2 DIGITAL HANDLE(coordinates handle)
img=rgb2gray(img);
img=im2bw(img,0.61);
imshow(img);
img=~img;
B=boundaries(img);
d=cellfun('length',B);
[max_d,k]=max(d);
C=B{k(1)};
[M,N]=size(img);
g=bound2im(C,M,N,min(C(:,1)),min(C(:,2)));
figure
imshow(g);