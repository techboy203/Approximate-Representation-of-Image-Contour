%Extrace the contour of the image
img=imread('maple.jpg');
img=rgb2gray(img);
img=im2bw(img,0.61);

%Given the coordinates of the contour points
img=~img;              % 0 is black color and 1 is white color
B=boundaries(img);     %B is a cell array
d=cellfun('length',B);
[max_d,k]=max(d);
C=B{k(1)};            %C includes the coordinates of the contour poionts
[M,N]=size(img);
g=bound2im(C,M,N,min(C(:,1)),min(C(:,2)));  % g is a binary image

ISE=10;       % Integral square error in PSO
T=100;        % T be the pre-specified maximum number of iterations
sizepop=30;   % the size of the population

%PSO parameter
c1=2;
c2=2;
r1=rand;
r2=rand;

%Maximum and minimum values of individuals and velocity
popmax=length(C);   popmin=10;
Vmax=popmax-1;   Vmin=1-popmax;

%Initialize the population
for i = 1:sizepop
    
     %random generation of a population
     temporary=randperm(popmax);
     fitness(i)=PSO_Fitness(temporary,C,ISE);   %caculate the fitness
     temporary2=randperm(2*popmax-1);
     temporary2=temporary2-popmax;
     v(i,:)=temporary2(1:length(fitness(i)));

end

%Best position P1=P2=...=Pk=Pg
[bestfitness bestindex]=min(fitness);
gbest=pop(bestindex,:);     % global best position
pbest=pop;                  % local  best position
fitnesspbest=fitness;       % local  best fitness
fitnessgbest=bestfitness;   % global best fitness

%interate for optimization
for i = 1:T
    for j=1:sizepop
%          v(j,:)=v(j,:)+c1*r1*()+c2*r2*();
    end
end

