function L = PSO_Fitness( P,C,ISE )
%L=PSO_Fitness() calulate the polygonal approximating L 
%   Input P is the random index of curve C
%   Input the digital planar curve C, C is a n-by-2 matrix which include
%   coordinates of the countour C.The PSO  ISE can control the  accuracy.
%   Output the polygonal approximating L 

 num  = length(P);   % the number of vertices of approximation polygon
 numv = length(C);   % the number of vertices of original curve C
 ISE1=0;             % initialize the error
 t=0;
 middle=num;

%caculate the ISE 
while ISE1<ISE  

    middle=floor(middle/2);              % dichotomy
    [P1,ind]=sort(P(1:middle));       % sort the   of vertices by index
    ISE1=0;
    for i=1:middle
        start=1+mod(P1(i)-1,numv);  
        tail=1+mod(P1(i+1)-1,numv);
        for j=start:tail
            vp=1+mod(j,numv);
            ISE1=ISE1+sqrt(abs(det([C(tail,:)-C(start,:);C(j,:)-C(start,:)]))/norm(C(tail,:)-C(start,:)))
        end
    end
    if ISE1<ISE
        t=middle;                     % mark the dichotomy's aim
    end
end

if t~=0&ISE1>ISE
     middle=2*t;
    while ISE1>ISE& (middle-t)>10
       middle1 = floor((t+middle)/2) ;
       [P1,ind]=sort(P(1:middle));       % sort the   of vertices by index
       ISE1=0;
       for i=1:middle
        start=1+mod(P1(i)-1,numv);  
        tail=1+mod(P1(i+1)-1,numv);
        for j=start:tail
            vp=1+mod(j,numv);
            ISE1=ISE1+sqrt(abs(det([C(tail,:)-C(start,:);C(j,:)-C(start,:)]))/norm(C(tail,:)-C(start,:)))
        end
       end
       if ISE1<ISE
          t=middle; 
       end
    end
end
if t~=0
    [P1,ind]=sort(P(1:t)); 
    L=P1(1:t,:);
end


    
end
